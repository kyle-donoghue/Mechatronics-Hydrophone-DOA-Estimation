#import necessary libraries
import threading, signal
from ctypes import *
from dwfconstants import *
import math
import time
import matplotlib.pyplot as plt
import sys
import numpy as np
from queue import Queue
import pandas as pd
from bokeh.plotting import figure, output_notebook, show #plotting library
from bokeh.layouts import column



def killHandler(signum, frame):
    dwf.FDwfDeviceCloseAll()
    exit(1)




k_highpass = [
                -0.0186146450073650, 0.000461324466420167, 0.000458071941757606, 0.000452363125204585, 0.000450467079562611, 0.000446031329053777, 0.000445409965002778, 0.000442172490947144, 0.000442741379587755, 0.000440549449560287, 0.000442243941943237, 0.000441097943993461, 0.000443962807008968, 0.000443775611683694, 0.000447601854570882, 0.000448253645598193, 0.000453326722161141, 0.000454536231811927, 0.000460693193258733, 0.000462632144915431, 0.000469611582883759, 0.000472117722494883, 0.000480193840609673, 0.000483007732945267, 0.000492161247013439, 0.000495005224967006, 0.000505538367872610, 0.000507963493022465, 0.000520420448674208, 0.000521009569581938, 0.000537253454719871, 0.000527587456963639, 0.000557112179055306, 0.000581928529464765, 0.000558254343407096, 0.000572437920389657, 0.000573815250485839, 0.000587867528165303, 0.000594155777815423, 0.000607545560619319, 0.000615399475392252, 0.000627981990608249, 0.000636378548201406, 0.000648161365614666, 0.000656570711907489, 0.000667511784159870, 0.000675783023974802, 0.000686248577848070, 0.000694239763803615, 0.000703977232432000, 0.000712009101165357, 0.000721054389020358, 0.000728916436963874, 0.000737609485920372, 0.000745193241681871, 0.000753374877057606, 0.000760738890350194, 0.000768462895863264, 0.000775587646032395, 0.000782703910278538, 0.000789533188414440, 0.000795924623352236, 0.000802637294251929, 0.000807609104912081, 0.000819514722824011, 0.000814616386365745, 0.000821417012767229, 0.000830503109193515, 0.000835162358522330, 0.000840401605706152, 0.000843032108416492, 0.000846412794576860, 0.000848065722091260, 0.000850495981394594, 0.000851498547507907, 0.000853126021847011, 0.000853469052202357, 0.000854358266111483, 0.000854045029252378, 0.000853964292771336, 0.000852428190430604, 0.000851481968338018, 0.000848788744457234, 0.000846432123970646, 0.000842647946033304, 0.000838839839361995, 0.000833619005364668, 0.000828468510378874, 0.000821838113027876, 0.000815277237417110, 0.000807114082745472, 0.000799173752697541, 0.000789483917365313, 0.000780305154089806, 0.000768845144135362, 0.000758900805612311, 0.000745104776191884, 0.000731055514925969, 0.000722162824337867, 0.000705582571388582, 0.000690142750871869, 0.000673034445089860, 0.000656625692943823, 0.000638928278572448, 0.000621230365350932, 0.000602114449379954, 0.000582617783094845, 0.000561754149462894, 0.000540415653177530, 0.000517740118439133, 0.000494451591191073, 0.000469782559444383, 0.000444848943079455, 0.000418663463190282, 0.000391672833773122, 0.000363977721009381, 0.000335308807645166, 0.000305810724956570, 0.000275550635154168, 0.000244370969728100, 0.000212326989352800, 0.000179382649067001, 0.000145548420390812, 0.000110886893185217, 7.51979396325640e-05, 3.87624222899154e-05, 1.10420384125380e-06, -3.68386968583439e-05, -7.73196145869747e-05, -0.000115203178867756, -0.000157090155051392, -0.000200512724335562, -0.000242268148105786, -0.000285777981449102, -0.000329423773477038, -0.000374957272268373, -0.000420799878632580, -0.000468185382271000, -0.000515708369214314, -0.000564567746814063, -0.000613592658042008, -0.000663956180873265, -0.000714477409464739, -0.000766166249590462, -0.000817910243170705, -0.000871435042601817, -0.000924736071014999, -0.000979492223841547, -0.00103454727824574, -0.00109068723274244, -0.00114716098827292, -0.00120480914771533, -0.00126265850345734, -0.00132161884526208, -0.00138070976310467, -0.00144094909411131, -0.00150125046654911, -0.00156269877708703, -0.00162402393973326, -0.00168670430336240, -0.00174901593386269, -0.00181207358822778, -0.00187740840436093, -0.00194056960805734, -0.00200511571821606, -0.00207059339451546, -0.00213659981828646, -0.00220305304011004, -0.00226957303010736, -0.00233652219915047, -0.00240359696292491, -0.00247127309398495, -0.00253908967758637, -0.00260743051028305, -0.00267577184981092, -0.00274459227322460, -0.00281368577308484, -0.00288316561797795, -0.00295210887408288, -0.00302207834666306, -0.00309136722456603, -0.00316133782374052, -0.00323092443153240, -0.00330099636392876, -0.00337062543477688, -0.00344076364703005, -0.00351045028326178, -0.00358063627564070, -0.00365024411381784, -0.00372035536963997, -0.00378978221180244, -0.00385988348348506, -0.00392873310989397, -0.00399909526665058, -0.00406760025822173, -0.00413605215725907, -0.00420534144407824, -0.00427382707668138, -0.00434181965040688, -0.00440937049638887, -0.00447660662883136, -0.00454367453715052, -0.00461036330707073, -0.00467674204468051, -0.00474251071410760, -0.00480787362682587, -0.00487266541163283, -0.00493713309209455, -0.00500098942224885, -0.00506383475377262, -0.00512651023500111, -0.00518866761507079, -0.00524974641049911, -0.00531071276311824, -0.00537052685794985, -0.00543000005265189, -0.00548841486419464, -0.00554641808861248, -0.00560329558551072, -0.00565965474206359, -0.00571486667971618, -0.00576954527494802, -0.00582307602150530, -0.00587594209044747, -0.00592762633294944, -0.00597896959863015, -0.00602801065976483, -0.00607804585040805, -0.00612593137909467, -0.00617298542257664, -0.00621881199101509, -0.00626414829304179, -0.00630814347681867, -0.00635136123591008, -0.00639301749236188, -0.00643383509940647, -0.00647318887759552, -0.00651183311783371, -0.00654902101402169, -0.00658534378033526, -0.00661989639810630, -0.00665373131533966, -0.00668663937154494, -0.00671769969018069, -0.00674783997687885, -0.00677675368161746, -0.00680416647097316, -0.00683058170076841, -0.00685546513870090, -0.00687927151559464, -0.00690152216999656, -0.00692270373454211, -0.00694237102531087, -0.00696091208472053, -0.00697792191611281, -0.00699369717275172, -0.00700818768492119, -0.00702107795057745, -0.00703281064115946, -0.00704364054613185, -0.00705178435853149, -0.00705968616347600, -0.00706568204078950, -0.00707080135719669, -0.00707387437235728, -0.00707607472897216, 0.992923559287084, -0.00707607472897216, -0.00707387437235728, -0.00707080135719669, -0.00706568204078950, -0.00705968616347600, -0.00705178435853149, -0.00704364054613185, -0.00703281064115946, -0.00702107795057745, -0.00700818768492119, -0.00699369717275172, -0.00697792191611281, -0.00696091208472053, -0.00694237102531087, -0.00692270373454211, -0.00690152216999656, -0.00687927151559464, -0.00685546513870090, -0.00683058170076841, -0.00680416647097316, -0.00677675368161746, -0.00674783997687885, -0.00671769969018069, -0.00668663937154494, -0.00665373131533966, -0.00661989639810630, -0.00658534378033526, -0.00654902101402169, -0.00651183311783371, -0.00647318887759552, -0.00643383509940647, -0.00639301749236188, -0.00635136123591008, -0.00630814347681867, -0.00626414829304179, -0.00621881199101509, -0.00617298542257664, -0.00612593137909467, -0.00607804585040805, -0.00602801065976483, -0.00597896959863015, -0.00592762633294944, -0.00587594209044747, -0.00582307602150530, -0.00576954527494802, -0.00571486667971618, -0.00565965474206359, -0.00560329558551072, -0.00554641808861248, -0.00548841486419464, -0.00543000005265189, -0.00537052685794985, -0.00531071276311824, -0.00524974641049911, -0.00518866761507079, -0.00512651023500111, -0.00506383475377262, -0.00500098942224885, -0.00493713309209455, -0.00487266541163283, -0.00480787362682587, -0.00474251071410760, -0.00467674204468051, -0.00461036330707073, -0.00454367453715052, -0.00447660662883136, -0.00440937049638887, -0.00434181965040688, -0.00427382707668138, -0.00420534144407824, -0.00413605215725907, -0.00406760025822173, -0.00399909526665058, -0.00392873310989397, -0.00385988348348506, -0.00378978221180244, -0.00372035536963997, -0.00365024411381784, -0.00358063627564070, -0.00351045028326178, -0.00344076364703005, -0.00337062543477688, -0.00330099636392876, -0.00323092443153240, -0.00316133782374052, -0.00309136722456603, -0.00302207834666306, -0.00295210887408288, -0.00288316561797795, -0.00281368577308484, -0.00274459227322460, -0.00267577184981092, -0.00260743051028305, -0.00253908967758637, -0.00247127309398495, -0.00240359696292491, -0.00233652219915047, -0.00226957303010736, -0.00220305304011004, -0.00213659981828646, -0.00207059339451546, -0.00200511571821606, -0.00194056960805734, -0.00187740840436093, -0.00181207358822778, -0.00174901593386269, -0.00168670430336240, -0.00162402393973326, -0.00156269877708703, -0.00150125046654911, -0.00144094909411131, -0.00138070976310467, -0.00132161884526208, -0.00126265850345734, -0.00120480914771533, -0.00114716098827292, -0.00109068723274244, -0.00103454727824574, -0.000979492223841547, -0.000924736071014999, -0.000871435042601817, -0.000817910243170705, -0.000766166249590462, -0.000714477409464739, -0.000663956180873265, -0.000613592658042008, -0.000564567746814063, -0.000515708369214314, -0.000468185382271000, -0.000420799878632580, -0.000374957272268373, -0.000329423773477038, -0.000285777981449102, -0.000242268148105786, -0.000200512724335562, -0.000157090155051392, -0.000115203178867756, -7.73196145869747e-05, -3.68386968583439e-05, 1.10420384125380e-06, 3.87624222899154e-05, 7.51979396325640e-05, 0.000110886893185217, 0.000145548420390812, 0.000179382649067001, 0.000212326989352800, 0.000244370969728100, 0.000275550635154168, 0.000305810724956570, 0.000335308807645166, 0.000363977721009381, 0.000391672833773122, 0.000418663463190282, 0.000444848943079455, 0.000469782559444383, 0.000494451591191073, 0.000517740118439133, 0.000540415653177530, 0.000561754149462894, 0.000582617783094845, 0.000602114449379954, 0.000621230365350932, 0.000638928278572448, 0.000656625692943823, 0.000673034445089860, 0.000690142750871869, 0.000705582571388582, 0.000722162824337867, 0.000731055514925969, 0.000745104776191884, 0.000758900805612311, 0.000768845144135362, 0.000780305154089806, 0.000789483917365313, 0.000799173752697541, 0.000807114082745472, 0.000815277237417110, 0.000821838113027876, 0.000828468510378874, 0.000833619005364668, 0.000838839839361995, 0.000842647946033304, 0.000846432123970646, 0.000848788744457234, 0.000851481968338018, 0.000852428190430604, 0.000853964292771336, 0.000854045029252378, 0.000854358266111483, 0.000853469052202357, 0.000853126021847011, 0.000851498547507907, 0.000850495981394594, 0.000848065722091260, 0.000846412794576860, 0.000843032108416492, 0.000840401605706152, 0.000835162358522330, 0.000830503109193515, 0.000821417012767229, 0.000814616386365745, 0.000819514722824011, 0.000807609104912081, 0.000802637294251929, 0.000795924623352236, 0.000789533188414440, 0.000782703910278538, 0.000775587646032395, 0.000768462895863264, 0.000760738890350194, 0.000753374877057606, 0.000745193241681871, 0.000737609485920372, 0.000728916436963874, 0.000721054389020358, 0.000712009101165357, 0.000703977232432000, 0.000694239763803615, 0.000686248577848070, 0.000675783023974802, 0.000667511784159870, 0.000656570711907489, 0.000648161365614666, 0.000636378548201406, 0.000627981990608249, 0.000615399475392252, 0.000607545560619319, 0.000594155777815423, 0.000587867528165303, 0.000573815250485839, 0.000572437920389657, 0.000558254343407096, 0.000581928529464765, 0.000557112179055306, 0.000527587456963639, 0.000537253454719871, 0.000521009569581938, 0.000520420448674208, 0.000507963493022465, 0.000505538367872610, 0.000495005224967006, 0.000492161247013439, 0.000483007732945267, 0.000480193840609673, 0.000472117722494883, 0.000469611582883759, 0.000462632144915431, 0.000460693193258733, 0.000454536231811927, 0.000453326722161141, 0.000448253645598193, 0.000447601854570882, 0.000443775611683694, 0.000443962807008968, 0.000441097943993461, 0.000442243941943237, 0.000440549449560287, 0.000442741379587755, 0.000442172490947144, 0.000445409965002778, 0.000446031329053777, 0.000450467079562611, 0.000452363125204585, 0.000458071941757606, 0.000461324466420167, -0.0186146450073650
                ]





#import SDK
if sys.platform.startswith("win"):
    dwf = cdll.dwf
elif sys.platform.startswith("darwin"):
    dwf = cdll.LoadLibrary("/Library/Frameworks/dwf.framework/dwf")
else:
    dwf = cdll.LoadLibrary("libdwf.so")

def kill():
    dwf.FDwfAnalogOutReset(hdwf, c_int(0))
    dwf.FDwfDeviceCloseAll()
    exit(1)

def killHandler(signum, frame):
    kill()

signal.signal(signal.SIGINT, killHandler)

#declare ctype variables
hdwf = c_int()
sts = c_byte()
hzAcq = c_double(1000000)
nSamples = 100000
rawData1 = (c_double*nSamples)()
rawData2 = (c_double*nSamples)()
dataToSend1 = np.zeros(nSamples)
dataToSend2 = np.zeros(nSamples)
cAvailable = c_int()
cLost = c_int()
cCorrupted = c_int()
fLost = 0
fCorrupted = 0




def record_set_up():
    global dwf, hdwf, hzAcq, nSamples


    #print(DWF version
    version = create_string_buffer(16)
    dwf.FDwfGetVersion(version)
    print("DWF Version: "+str(version.value))

    #open device
    print("Opening first device")
    dwf.FDwfDeviceOpen(c_int(-1), byref(hdwf))

    if hdwf.value == hdwfNone.value:
        szerr = create_string_buffer(512)
        dwf.FDwfGetLastErrorMsg(szerr)
        print(str(szerr.value))
        print("failed to open device")
        quit()

    device_name = create_string_buffer(32)
    dwf.FDwfEnumDeviceName(c_int(0), device_name)
    print("First Device: " + str(device_name.value))


    #set up acquisition
    dwf.FDwfAnalogInBufferSizeSet(hdwf, c_int(8192)) #set buffer to 8kB (max record length = 8192/1M = )
    dwf.FDwfAnalogInChannelEnableSet(hdwf, c_int(0), c_bool(True))
    dwf.FDwfAnalogInChannelRangeSet(hdwf, c_int(0), c_double(5))
    dwf.FDwfAnalogInAcquisitionModeSet(hdwf, acqmodeRecord)
    dwf.FDwfAnalogInFrequencySet(hdwf, hzAcq)
    dwf.FDwfAnalogInRecordLengthSet(hdwf, c_double(-1)) # -1 infinite record length

    #wait at least 2 seconds for the offset to stabilize
    time.sleep(2)

class Data_Record(threading.Thread):
    def __init__(self, data_process_thread, q):
        threading.Thread.__init__(self)
        self.data_process_thread = data_process_thread
        self.q = q

    def run(self):
        global dwf, hdwf, hzAcq, nSamples, rawData1, rawData2, cAvailable, cLost, cCorrupted, fLost, fCorrupted, timeElapsed

        print("Starting oscilloscope")
        dwf.FDwfAnalogInConfigure(hdwf, c_int(0), c_int(1))
        
        num = 0
        while True:
            cSamples = 0
            cLostNum = 0
            cCorrNum = 0
            times = time.time()
            while cSamples < nSamples:
                dwf.FDwfAnalogInStatus(hdwf, c_int(1), byref(sts))
                if cSamples == 0 and (sts == DwfStateConfig or sts == DwfStatePrefill or sts == DwfStateArmed) :
                    # Acquisition not yet started.
                    continue

                dwf.FDwfAnalogInStatusRecord(hdwf, byref(cAvailable), byref(cLost), byref(cCorrupted))
                
                cSamples += cLost.value

                if cLost.value :
                    fLost = 1
                    cLostNum += cLost.value
                if cCorrupted.value :
                    fCorrupted = 1
                    cCorrNum += cCorrupted.value
                if cAvailable.value==0 :
                    continue

                if cSamples+cAvailable.value > nSamples :
                    cAvailable = c_int(nSamples-cSamples)

                dwf.FDwfAnalogInStatusData(hdwf, c_int(0), byref(rawData1, sizeof(c_double)*cSamples), cAvailable) # get channel 1 data
                dwf.FDwfAnalogInStatusData(hdwf, c_int(1), byref(rawData2, sizeof(c_double)*cSamples), cAvailable) # get channel 2 data
                cSamples += cAvailable.value

            dataToSend1 = np.ctypeslib.as_array(rawData1)
            dataToSend2 = np.ctypeslib.as_array(rawData2)
            timeElapsed = time.time() - times
            num += 1
            queueData = [dataToSend1, dataToSend2, timeElapsed, cLost, cCorrupted, num]
            self.q.put(queueData)
            self.data_process_thread.event.set()
            if num == 20:
                break
        dwf.FDwfAnalogOutReset(hdwf, c_int(0))
        dwf.FDwfDeviceCloseAll()
        self.data_process_thread.join()

        print("Recording done")
        if fLost:
            print("Samples were lost! Reduce frequency")
        if fCorrupted:
            print("Samples could be corrupted! Reduce frequency")

        return
    """times = time.time() - times
    print(cSamples)
    print(times)
    print(cSamples/times)
    print()
    print(cLostNum)
    print(cCorrNum)
    print()
    print(str(cCorrNum/cSamples*100)+"%")"""
    """print("rolling data:")
    print("\t[totalsamples]\t"+str(totalSamples))
    print("\t[average samples/second]\t"+str(totalSamples/(time.time()-totalTime)))
    print("\t [samples lost]\t"+str(cLostNum))
    print("\t [samples corrupt]\t"+str(cCorrNum))"""

        

class Data_Process(threading.Thread):
    def __init__(self, event, q):
        threading.Thread.__init__(self)
        self.event = event
        self.q = q
        self.bigdata = np.empty(0)

    def run(self):
        print("waiting for signal")
        while True:
            self.event.wait()

            queueData = self.q.get()

            procTimeElapsed = time.time()
            
            num = queueData[5]
            raw1 = queueData[0]
            raw2 = queueData[1]
            timeElapsed = queueData[2]
            lostNum = queueData[3].value
            corrNum = queueData[4].value
            
            self.bigdata = np.append(self.bigdata, raw1)
            
            if num == 20:
                print(len(self.bigdata))
                y = self.bigdata
                # y = np.absolute(np.fft.rfft(self.bigdata))
                x = np.arange(0,len(y))/1000000

                y1 = np.convolve(y,k_highpass)
                x1 = np.arange(0,len(y1))/1000000

                # fig = go.Figure()
                # fig.add_trace(
                #     go.Scattergl(
                #         x = x,
                #         y = self.bigdata,
                #         mode = 'markers',
                #         marker = dict(
                #             line = dict(
                #                 width = 1,
                #                 color = 'DarkSlateGrey')
                #         )
                #     )
                # )

                # fig.show()
                TOOLTIPS = [
                    ("(x,y)", "($x, $y)"),
                ]

                fig = figure(
                    tools="pan,box_zoom,wheel_zoom,zoom_in,zoom_out,reset,save",
                    title="Data Plot",
                    #y_axis_type="log",
                    #y_range=[-1, 1],
                    x_axis_label='t',
                    y_axis_label='V',
                    plot_width=600, plot_height=400,
                    tooltips=TOOLTIPS,
                ) 
                fig2 = figure(
                    tools="pan,box_zoom,wheel_zoom,zoom_in,zoom_out,reset,save",
                    title="RFFT plot",
                    #y_axis_type="log",
                    #y_range=[-1, 1],
                    x_axis_label='Freq (Hz)',
                    y_axis_label='Amplitude',
                    plot_width=600, plot_height=400,
                    tooltips=TOOLTIPS,
                )

                # plot some data ('renderers' in Bokeh)
                #fig.circle(x, x, legend_label="y=x", fill_color="white", size=8)
                print("line1")
                fig.line(x, y, legend_label="REG", line_width=3, line_color="red")
                print("line2")

                fig.line(x1, y1, legend_label="CONVOLVE", line_width=3, line_color="BLUE")
                print("line3")

                y3 = np.absolute(np.fft.rfft(y1))
                x3 = np.fft.rfftfreq(y1.size,d=1./1000000)
                fig2.line(x3, y3, legend_label="FFT", line_width=3, line_color="GREEN")

                # show the results
                show(column(fig,fig2))

                f = open("regular_data.csv", "w")
                for v in y:
                    f.write("%s\n" % v)
                f.close()
                f = open("highpass_data.csv", "w")
                for v in y1:
                    f.write("%s\n" % v)
                f.close()
                f = open("rfft_data.csv", "w")
                for v in y3:
                    f.write("%s\n" % v)
                f.close()
                


            fft1 = np.fft.rfft(raw1)
            fft2 = np.fft.rfft(raw2)  
            i1 = np.argmax(np.absolute(fft1))
            i2 = np.argmax(np.absolute(fft2))
            t1 = np.angle(fft1[i1]) / (2*np.pi*40000)
            t2 = np.angle(fft2[i2]) / (2*np.pi*40000)
            theta = np.arctan2(-(t2),-(2*(t1)-(t2)))
            degree = theta*180/np.pi

            procTimeElapsed = time.time() - procTimeElapsed
            
            # x = range(0,len(raw1))
            # fig = px.line(x=x ,y =raw1,labels={'x':'x', 'y':'data'},markers=True)
            # fig.show()

            print("data: "+str(num))
            print("\t[record time]\t\t\t"+str(timeElapsed))
            print("\t[process time]\t\t\t"+str(procTimeElapsed))
            print("\t[samples]\t\t\t"+str(len(raw1)))
            print("\t[average samples/second]\t"+str(nSamples/(timeElapsed)))
            print("\t[samples lost]\t\t\t"+str(lostNum))
            print("\t[samples corrupt]\t\t"+str(corrNum))
        return

def data_communicate():
    while True:
        a = 1
    return


if __name__ == "__main__":

    time.sleep(10)
    record_set_up()

    q = Queue() #define queue to pass data between threads

    data_process_event = threading.Event()
    data_process_thread = Data_Process(data_process_event, q)
    data_process_thread.start() #set up process thead

    data_record_thread = Data_Record(data_process_thread, q)
    data_record_thread.start() #set up record thread

    data_record_thread.join() #start record thread


    #recording_thread = threading.Thread(target=data_record, args=())
    #processing_thread = threading.Thread(target=data_process, args=())
    communicating_thread = threading.Thread(target=data_communicate, args=())

    #recording_thread.start()
    #processing_thread.start()
    communicating_thread.start()

    #recording_thread.join()
    #processing_thread.join()
    communicating_thread.join()

